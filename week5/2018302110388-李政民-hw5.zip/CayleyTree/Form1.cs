﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CayleyTree
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Graphics graphics;
        double th1;
        double th2;
        double per1;
        double per2;

        private void button1_Click(object sender, EventArgs e)//画树按钮
        {
            if(radioButton2.Checked)
            {
                th1 = int.Parse(textBox1.Text) * Math.PI / 180;
                th2 = int.Parse(textBox2.Text) * Math.PI / 180;
                per1 = double.Parse(textBox3.Text);
                per2 = double.Parse(textBox4.Text);
            }
            else
            {
                Random r1 = new Random();
                Random r2 = new Random();
                Random r3 = new Random();
                Random r4 = new Random();
                th1 = r1.Next(0,180) * Math.PI / 180;
                th1 = r2.Next(0, 180) * Math.PI / 180;
                per1 = (double)r3.Next(0,1000)/1000;
                per2 = (double)r4.Next(0, 1000) / 1000;
            }
            if (graphics == null) graphics = this.CreateGraphics();
            drawCayleyTree(10, 300, 400, 100, -Math.PI / 2);
        }//10, 200, 310, 100, -Math.PI / 2

        void drawCayleyTree(int n,
                double x0, double y0, double leng, double th)
        {
            if (n == 0) return;

            double x1 = x0 + leng * Math.Cos(th);
            double y1 = y0 + leng * Math.Sin(th);

            double k = double.Parse(textBox5.Text);
            double x2 = x0 + leng * k * Math.Cos(th);//
            double y2 = y0 + leng * k * Math.Sin(th);//
            if(checkBox1.Checked)  drawLine(x0, y0, x1, y1);
            else  drawLines(x0, y0, x1, y1);
            if(checkBox3.Checked)  drawLine(x0, y0, x2, y2);
            else  drawLines(x0, y0, x2, y2);

            drawCayleyTree(n - 1, x1, y1, per1 * leng, th + th1);
            drawCayleyTree(n - 1, x2, y2, per2 * leng, th - th2);
        }
        void drawLine(double x0, double y0, double x, double y)
        {
            graphics.DrawLine(
                Pens.Blue,
                (int)x0, (int)y0, (int)x, (int)y);
        }
        void drawLines(double x0, double y0, double x, double y)
        {
            graphics.DrawLine(
                Pens.Red,
                (int)x0, (int)y0, (int)x, (int)y);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)//清空按钮
        {
            graphics.Clear(this.BackColor);
            graphics.Dispose();
            graphics = null;
        }

    }
}
